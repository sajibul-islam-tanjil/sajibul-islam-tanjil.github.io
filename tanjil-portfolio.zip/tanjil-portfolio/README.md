# Tanjil — Personal Portfolio

A responsive personal portfolio made with HTML5, CSS3 and vanilla JavaScript.

## Run locally
Open `index.html` in a browser, or use the VS Code Live Server extension.

## Before publishing
1. Replace the university, college, school and passing-year placeholders in `index.html`.
2. Replace sample projects with projects you have actually built.
3. Update GitHub, LinkedIn and email links.
4. Add your real certifications, achievements and profile photo if available.
5. Check every link and test on mobile.

## Deploy
Upload this folder to a GitHub repository and enable GitHub Pages from **Settings → Pages**, or drag the folder into Netlify Drop.
